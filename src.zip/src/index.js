import React, { Component } from 'react';
import ReactDOM from 'react-dom';
import hardcodedArrayOfCategories from './hardcoded_array_of_categories';

import CategoryItemAddForm from './components/category_item_add_form';
import CategoryList from './components/category_list';
import './style.css'

class App extends Component {
  constructor(props) {
    super(props);

    this.state = {
      categories: [...hardcodedArrayOfCategories]
    }
  }

  categoryAdd(category) {
    this.setState({
      categories: [...this.state.categories, category]
    });
  }

  render() {
    return (
      <div>
        <CategoryItemAddForm onFormSubmit={category => this.categoryAdd(category)} />
        <CategoryList categories={this.state.categories} />
      </div>
    );
  }
}

ReactDOM.render(
  <App />,
  document.getElementById('root')
);
